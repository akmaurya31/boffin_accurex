<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class User_lib
{
    protected $CI;

    public function __construct()
    {
        // Get CI instance
        $this->CI =& get_instance();
    }

    public function get_allowed_ips($user_id){
        $this->CI->db->select('ip_address');
        $this->CI->db->where('user_ID', $user_id);
        $query = $this->CI->db->get('user_ips');

        return array_column($query->result_array(), 'ip_address');
    }


    public function getUserInfoByAuthID($authID){
        $user = $this->CI->db->select('*')
                             ->from('auth')
                             ->where('auth_ID',$authID)
                             ->join('users','users.user_ID = auth.user_ID')
                             ->join('users_key_db','users_key_db.user_ID = auth.user_ID')
                             ->get();
        return $user->result();
    }

    public function read_notification($id){

    }

    public function getAllNotificationDESC($user_ID){
        $query = $this->CI->db->select("*")
                        ->from("notifications")
                        ->where("receipent_user_ID",$user_ID)
                        ->order_by("notification_ID","DESC")
                        ->join('users','users.user_ID = notifications.forworded_user_ID')
                        ->get();
        return $query->result();
    }

    function getInitials($fullName) {
        // Trim and explode by spaces
        $names = explode(' ', trim($fullName));

        $firstInitial = isset($names[0]) ? substr($names[0], 0, 1) : '';
        $lastInitial = count($names) > 1 ? substr($names[count($names) - 1], 0, 1) : '';

        return strtoupper($firstInitial . $lastInitial);
    }

    public function getNotificationByNotificationID($id){
        $query = $this->CI->db->select("*")
                                ->from("notifications")
                                ->where("notification_ID",$id)
                                ->join('users','users.user_ID = notifications.forworded_user_ID')
                                ->get();
        return $query->result();
    }

    function timeAgo($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = [
            'y' => 'y',
            'm' => 'month',
            'w' => 'w',
            'd' => 'd',
            'h' => 'h',
            'i' => 'm',
            's' => 's',
        ];

        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? '' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 2);
        return $string ? implode(' ', $string) . ' ago' : 'just now';
    }

    public function setAsSeen($id){
        $query = $this->CI->db->set('status','seen')
                              ->where('notification_ID',$id)
                              ->update('notifications');
        return $this->CI->db->affected_rows();
    }



}
