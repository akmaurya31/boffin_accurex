<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ip_check {

    public function check_user_ip()
    {

        $CI =& get_instance();
        $CI->load->library('session');

        // Check if user is logged in and NOT an admin (adjust this as per your logic)
        if ($CI->session->userdata('user_type') === 'user') {
            $user_ip = $CI->input->ip_address();

            // You can fetch allowed IPs from DB or hard-code for testing
            $CI->load->library('user_lib');
            $user_id = $CI->session->userdata('user_id');

            $allowed_ips = $CI->user_lib->get_allowed_ips($user_id); // should return an array

            if (!in_array($user_ip, $allowed_ips)) {
                // IP not allowed, redirect or show error
                show_error('Access denied. Your IP address is not allowed.', 403);
            }


        }
    }
}
